// 5 inline function to calculate maximum of two  numbers
#include<iostream> 
using namespace std;
inline int sum(int x,int y)
{
       return(x+y);
       }
       int main ()
       {
           int m=10,n=25;
           int a,b,c,d;
           c=sum(6,8);
           cout<<"sum of two numb is:"<<c<<endl;
           d=sum(m,n);
           cout<<"sum of two no is"<<d<<endl;
                     return 0;
           }
           
