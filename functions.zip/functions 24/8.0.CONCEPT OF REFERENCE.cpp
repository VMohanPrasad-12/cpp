// 8 EXAMPLE OF REFERENCE
#include<iostream>
using namespace std;
main()
{
      int i=10;
      int &j=i;//refrence vriable
      cout<<"i ="<<i<<"j = "<<j<<"\n";
      j=20;
      cout<<"i="<<i<<"j ="<<j;
     
      }
      
